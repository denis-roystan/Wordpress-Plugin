<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Uninstallation actions here
function wpab_delete_plugin()
{
	global $wpdb;

	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_appointments' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_conf' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_services' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_timeoff' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_locations' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_providers' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_customers' ) );
	$wpdb->query( sprintf( "DROP TABLE IF EXISTS %s", $wpdb->prefix . 'wpab_timeblocks' ) );
}

wpab_delete_plugin();
?>