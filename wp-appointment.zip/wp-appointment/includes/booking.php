<?php
	if(!empty($_GET['msg']) && $_GET['msg']==2) {
    	$message = $_GET['msg'];
?>
<div class="alert alert-success msg">
  <strong>Deleted!</strong> Appointment deleted successfully !
</div>
<?php
    }
?>

<?php
	if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_appointments";

        // sanitize form values
        $name    = $_POST["title"];
        $email = sanitize_email( $_POST["email"] );
        $location = $_POST["location"];
        $service = $_POST["service"];
        $provider = $_POST["provider"];
        $date_select = $_POST["date_select"];
        $time_avbl = $_POST["time_avbl"];
        $date = new DateTime($date_select);
		$time = new DateTime($time_avbl);
		$starts_at = new DateTime($date->format('Y-m-d') .' ' .$time->format('H:i'));
		$starts_at = $starts_at->format('Y-m-d H:i:s');
        $cost = absint( $_POST["cost"] );
        $duration = absint( $_POST["duration"] );

       	$appt = array($name, $service, $provider, $location, $starts_at, $duration, $cost);
        // echo $starts_at->format('Y-m-d H:i:s');

       	$query =  $wpdb->query($wpdb->prepare(
		    "INSERT INTO $table_name (customer_id, service_id, provider_id, location_id, starts_at, duration, price) VALUES ( %s, %s, %s, %s, %s, %s, %s )",
		    $appt
		));

        if($query){
	        $msg_success = "<div class='alert alert-info alert-dismissable'>Appointment has been successfully created</div>";
        }
        else{
        	$msg_success = "<div class='alert alert-warning alert-dismissable'>Appointment has not been created</div>";
        }
    }
?>

<div class="page-header">
<?php
	$var = $GLOBALS['title'];
	echo "<h1 class=''>$var</h1>";
?>
<?php echo $msg_success; ?>
</div>

<div class="col-md-12">
	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#view"><span class="glyphicon glyphicon-list"></span>&nbsp;&nbsp;View</a></li>
	  <li><a data-toggle="tab" href="#add"><span class="glyphicon glyphicon-plus"></span>&nbsp;&nbsp;Add</a></li>
	</ul>

	<div class="tab-content">
	  <div id="view" class="tab-pane fade in active">
	  	<br/>
    	<table class="table table-striped table-responsive">
			<thead>
			  <tr>
			    <th>Name</th>
			    <th>Email</th>
			    <th>Date/Time</th>
			    <th>Service</th>
			    <th>Provider</th>
			    <th>Location</th>
			    <th>Actions</th>
			  </tr>
			</thead>
			<tbody>
			  	<?php 
					global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_appointments";
					$select_query = $wpdb->get_results($wpdb->prepare( "
						SELECT CONCAT( b.first_name,  ' ', b.last_name ) AS uname, b.email, a.starts_at, e.name as service, d.name as provider, c.name as location, a.duration, a.price, a.seats, a.approved, a.completed, a.created_at, a.id
						FROM wp_wpab_appointments a
						INNER JOIN wp_wpab_customers b ON a.customer_id = b.id
						INNER JOIN wp_wpab_locations c ON a.location_id = c.id
						INNER JOIN wp_wpab_providers d ON a.provider_id = d.id
						INNER JOIN wp_wpab_services e ON a.service_id = e.id
					",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
					<tr>
					    <td><?php echo $value->uname ?></td>
					    <td><?php echo $value->email ?></td>
					    <td><?php echo $value->starts_at ?></td>
					    <td><?php echo $value->service ?></td>
					    <td><?php echo $value->provider ?></td>
					    <td><?php echo $value->location ?></td>
					    <td>
					    	<a href="<?php echo plugin_dir_url( __FILE__ ) ?>delete/delete-appointment.php?id=<?php echo $value->id ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>" class="delete" data-id="<?php echo $value->id ?>"><span class="glyphicon glyphicon-trash"></span></a>
					    </td>
					</tr>
				<?php
					endforeach;
					}
					else { 
				?>
					<tr>
						<td align="center" colspan="7">No Records To Display !</td>
					</tr>
				<?php
					}
				?>
			</tbody>
		</table>
	  </div>
	  <div id="add" class="tab-pane fade">
	    <br/><br/>
	    <form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="" enctype="multipart/form-data">
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="title">Name</label>
		    <div class="col-sm-10">
		      <select class="form-control" id="title" name="title" data-live-search="true" title="Select Customer">
			    <?php
		      		global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_customers";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,first_name,last_name,email FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
						<option value="<?php echo $value->id ?>"><?php echo $value->first_name . " " . $value->last_name ?></option>
					
				<?php
					endforeach;
					}
					else { 
				?>
					<option>No Records To Display !</option>
				<?php
					}
		      	?>
			  </select>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="email">Email</label>
		    <div class="col-sm-10"> 
		      <input type="text" class="form-control" id="email" name="email" readonly="readonly" value="">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="location">Location</label>
		    <div class="col-sm-10">
		      <select class="form-control" id="location" name="location" data-live-search="true" title="Select Location">
			    <?php
		      		global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_locations";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,name FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
						<option value="<?php echo $value->id ?>"><?php echo $value->name ?></option>
					
				<?php
					endforeach;
					}
					else { 
				?>
					<option>No Records To Display !</option>
				<?php
					}
		      	?>
			  </select>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="service">Service</label>
		    <div class="col-sm-10">
		      <select class="form-control" id="service" name="service" data-live-search="true" title="Select Service">
			  </select>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="provider">Service Provider</label>
		    <div class="col-sm-10">
		      <select class="form-control" id="provider" name="provider" data-live-search="true" title="Select Provider">
			  </select>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Date</label>
		    <div class="col-sm-10">        		
		        <div class="col-md-10" style="overflow:hidden;">
				    <div class="form-group">
				        <div class="row">
				            <div class="col-md-8">
				                <div id="datetimepicker12"></div>
				            </div>
				        </div>
				    </div>
				    <script type="text/javascript">
				        $(function () {
				            $('#datetimepicker12').datetimepicker({
				            	format: 'YYYY-MM-DD',
				                inline: true,
				                sideBySide: true
				            });
				        });
				    </script>
			    </div>
			    <input type="hidden" name="date_select" id="date_select" value="" class="form-control">			    
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Time</label>
		    <div class="col-sm-10">
		    	<div class='col-md-8' id="time_avl">
		      		Please select above details..!!!
		      	</div>
		      	<input type="hidden" name="time_avbl" id="time_avbl" class="form-control" value="">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="cost">Cost</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="cost" name="cost" readonly="readonly">
		    </div>
		  </div>
		  <input type="hidden" name="duration" value="" id="duration">
		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default" name="form-submitted">Confirm Appointment</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
	<div style="display: none;" class="wpab_home_url"><?php echo plugin_dir_url( __FILE__ ); ?></div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#title,#location,#service,#provider').selectpicker({
		  size: 8
		});
	});	
</script>

<script type="text/javascript">
	$(document).ready(function() {
		var $customer_select = "";
		var $location_select = "";
		var $service_select = "";
		var $provider_select = "";
		var $wpab_url = $(".wpab_home_url").text();
		//console.log($wpab_url);

		$("#title").change(function(){
			$customer_select = $(this).find(":selected").attr('value');

			$.ajax({
				url: $wpab_url + 'ajax/ue_relation.php',
				type: 'POST',
				data: { 
			        'customer_name': $customer_select,
			    },
				success: function(data) {
					//console.log(data);
					$("#email").val(data);
				}
			});		
		});

		$("#location").change(function(){
			$location_select = $(this).find(":selected").attr('value');

			$.ajax({
				url: $wpab_url + 'ajax/ls_relation.php',
				type: 'POST',
				data: { 
			        'location_name': $location_select,
			    },
				success: function(data) {
					//console.log(data);
					$("#service").empty();
					$("#service").append(data);
					$("#service").selectpicker('refresh');
				}
			});		
		});

		$("#service").change(function(){
			$service_select = $(this).find(":selected").attr('value');
			var $cprice = $(this).find(":selected").attr('data-price');
			
			$("#cost").val($cprice);

			var $sduration = $(this).find(":selected").attr('data-duration');
			
			$("#duration").attr('value', $sduration);

			$.ajax({
				url: $wpab_url + 'ajax/lsp_relation.php',
				type: 'POST',
				data: { 
					'location_name': $location_select,
			        'service_name': $service_select,
			    },
				success: function(data) {
					//console.log(data);
					$("#provider").empty();
					$("#provider").append(data);
					$("#provider").selectpicker('refresh');
				}
			});		
		});

		$("#provider").change(function(){
			$provider_select = $(this).find(":selected").attr('value');

			$.ajax({
				url: $wpab_url + 'ajax/lspdt_relation.php',
				type: 'POST',
				data: { 
					'location_name': $location_select,
			        'service_name': $service_select,
			        'provider_name': $provider_select,
			    },
				success: function(data) {
					var $ans = jQuery.parseJSON(data);
        			console.log($ans);

		            $('#datetimepicker12').data("DateTimePicker").minDate($ans[0]);
		            $('#datetimepicker12').data("DateTimePicker").maxDate($ans[1]);
		            //$('#datetimepicker12').data("DateTimePicker").daysOfWeekDisabled([3,6]);
		            $("#date_select").attr('value', $ans[0]); 
		            var a = $ans[2];
		            var b = $ans[3];
		            var c = $ans[4];

		            ajaxtime(a,b,c);
				}
			});		
		});

		function ajaxtime($param1,$param2,$param3) {
			// body...
			$.ajax({
				url: $wpab_url + 'ajax/t_relation.php',
				type: 'POST',
				data: {
					'location_name': $location_select,
			        'service_name': $service_select,
			        'provider_name': $provider_select, 
					'starts_at': $param1,
					'ends_at': $param2,
					'interval': $param3,
			    },
				success: function(data) {
					//var $ans = jQuery.parseJSON(data);
        			//console.log(data);

        			$("#time_avl").empty();
        			$("#time_avl").append(data);
				}
			});
		}


		$("#datetimepicker12").on("dp.change" , function(e){ 
			//console.log(e.date.format("YYYY-MM-DD"));
			$("#date_select").attr('value', e.date.format("YYYY-MM-DD")); 
		});

		$("#time_avl").on('click', 'button', function(event) {
			//console.log($(this).text());
			$('#time_avl button').css('background', '#fff');
			$('#time_avl button').css('color', '#000');
			$("#time_avbl").attr('value', $(this).text());
			$(this).css('background', 'green');
			$(this).css('color', '#fff');
		});
	});		
</script>

<script type="text/javascript">
	$(document).ready(function() {
		$(".alert-dismissable,.msg").fadeTo(2000, 500).slideUp(500, function(){
		    $(".alert-dismissable,.msg").alert('close');
		});
	});		
</script>