<div class="page-header">
<?php
	$var = $GLOBALS['title'];
	echo "<h1 class=''>$var</h1>";
?>
</div>