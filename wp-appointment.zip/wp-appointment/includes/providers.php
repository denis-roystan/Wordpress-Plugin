<?php
	if(!empty($_GET['msg']) && $_GET['msg']==2) {
    	$message = $_GET['msg'];
?>
<div class="alert alert-success msg">
  <strong>Deleted!</strong> Provider deleted successfully !
</div>
<?php
    }
?>

<?php
	if(!empty($_GET['msg']) && $_GET['msg']==1) {
    	$message = $_GET['msg'];
?>
<div class="alert alert-success msg">
  <strong>Updated!</strong> Provider edited successfully !
</div>
<?php
    }
?>

<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_providers";

        // sanitize form values
        $name    = sanitize_text_field( $_POST["title"] );
        $description = esc_textarea( $_POST["description"] );
        $email = sanitize_email( $_POST["email"] );

       	$query =  $wpdb->query($wpdb->prepare(
		    "INSERT INTO $table_name (name, description, email) VALUES ( %s, %s, %s )",
		    array(
		        $name,
		        $description,
		        $email
		    )
		));

        if($query){
	        $msg_success = "<div class='alert alert-info alert-dismissable'>Provider has been successfully created</div>";
        }
        else{
        	$msg_success = "<div class='alert alert-warning alert-dismissable'>Provider has not been created</div>";
        }
    }
?>


<div class="page-header">
<?php
	$var = $GLOBALS['title'];
	echo "<h1 class=''>$var</h1>";
?>
<?php echo $msg_success; ?>
</div>
<div class="col-md-12">
	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#view"><span class="glyphicon glyphicon-list"></span>&nbsp;&nbsp;View</a></li>
	  <li><a data-toggle="tab" href="#add"><span class="glyphicon glyphicon-plus"></span>&nbsp;&nbsp;Add</a></li>
	</ul>

	<div class="tab-content">
	  <div id="view" class="tab-pane fade in active">
	  	<br/>
    	<table class="table table-striped table-responsive">
			<thead>
			  <tr>
			    <th>Title</th>
			    <th>Description</th>
			    <th>Email</th>
			    <th>Actions</th>
			  </tr>
			</thead>
			<tbody>
			  <?php 
					global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_providers";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,name,description,email FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>

					<tr>
					    <td><?php echo $value->name ?></td>
					    <td><?php echo $value->description ?></td>
					    <td><?php echo $value->email ?></td>
					    <td>
					    	<a href="<?php echo admin_url() ?>?page=wpab_provider_edit&id=<?php echo $value->id ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>" class="edit" data-id="<?php echo $value->id ?>"><span class="glyphicon glyphicon-edit"></span></a>
					    	&nbsp;
					    	<a href="<?php echo plugin_dir_url( __FILE__ ) ?>delete/delete-provider.php?id=<?php echo $value->id ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>" class="delete" data-id="<?php echo $value->id ?>"><span class="glyphicon glyphicon-trash"></span></a>
					    </td>
					</tr>
				<?php
					endforeach;
					}
					else { 
				?>
					<tr>
						<td align="center" colspan="3">No Records To Display !</td>
					</tr>
				<?php
					}
				?>
			</tbody>
		</table>
	  </div>
	  <div id="add" class="tab-pane fade">
	    <br/><br/>
	    <form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="title">Name</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" pattern="[a-zA-Z0-9 ]+" id="title" name="title" required="required">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="description">Description</label>
		    <div class="col-sm-10"> 
		      <textarea class="form-control" rows="5" id="description" name="description" required="required"></textarea>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="email">Email</label>
		    <div class="col-sm-10">
		      <input type="email" class="form-control" id="email" name="email" required="required">
		    </div>
		  </div>
		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default" name="form-submitted">Add New Provider</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$(".alert-dismissable,.msg").fadeTo(2000, 500).slideUp(500, function(){
		    $(".alert-dismissable,.msg").alert('close');
		});
	});		
</script>