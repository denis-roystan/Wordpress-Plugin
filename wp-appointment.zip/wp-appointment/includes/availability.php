<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name_abvl = $wpdb->prefix . "wpab_timeblocks";
    	$table_name_loc = $wpdb->prefix . "wpab_loc";
    	$table_name_serv = $wpdb->prefix . "wpab_serv";
    	$table_name_week = $wpdb->prefix . "wpab_week";

        // sanitize form values
        $provider    = $_POST["provider"];
        $location = $_POST["loc"];
        $service = $_POST["serv"];
        $start_time    = $_POST["starttime"];
        $end_time    = $_POST["endtime"];
        $interval    = $_POST["interval"];
        $appt_when    = $_POST["appt_when"];
        $weekdays    = $_POST["weekdays"];
        $valid_from    = sanitize_text_field( $_POST["valid_from"] );
        $valid_to    = sanitize_text_field( $_POST["valid_to"] );
        $capacity    = absint( $_POST["capacity"] );

        /*echo "<pre>";
        echo "$provider" . "<br/>";
        print_r($location);
        print_r($service);
        echo "$start_time" . "<br/>";
        echo "$end_time" . "<br/>";
        echo "$interval" . "<br/>";
        echo "$appt_when" . "<br/>";
        print_r($weekdays);
        echo "$valid_from" . "<br/>";
        echo "$valid_to" . "<br/>";
        echo "$capacity" . "<br/>";        
        echo "</pre>" . "<br/>";*/

       	$query =  $wpdb->query($wpdb->prepare(
		    "INSERT INTO $table_name_abvl (provider_id, starts_at, ends_at, appt_interval, avl_when, valid_from, valid_to, capacity) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s )",
		    array(
		        $provider,
		        $start_time,
		        $end_time,
		        $interval,
		        $appt_when,
		        $valid_from,
		        $valid_to,
		        $capacity
		    )
		));

        if($query){

        	$last_insert_id = mysql_insert_id();

        	foreach($location as $value) {
			    $query =  $wpdb->query($wpdb->prepare(
				    "INSERT INTO $table_name_loc (avail_id, location_id) VALUES ( %s, %s )",
				    array(
				        $last_insert_id,
				        $value
				    )
				));
			}

			foreach($service as $value) {
			    $query =  $wpdb->query($wpdb->prepare(
				    "INSERT INTO $table_name_serv (avail_id, service_id) VALUES ( %s, %s )",
				    array(
				        $last_insert_id,
				        $value
				    )
				));
			}

			foreach($weekdays as $value) {
			    $query =  $wpdb->query($wpdb->prepare(
				    "INSERT INTO $table_name_week (avail_id, week_id) VALUES ( %s, %s )",
				    array(
				        $last_insert_id,
				        $value
				    )
				));
			}

	        $msg_success = "<div class='alert alert-info alert-dismissable'>New Availability Created Successfully</div>";
        }
        else{
        	$msg_success = "<div class='alert alert-warning alert-dismissable'>Availability has not been created</div>";
        }
    }
?>


<div class="page-header">
<?php
	$var = $GLOBALS['title'];
	echo "<h1 class=''>$var</h1>";
?>
<?php echo $msg_success; ?>
</div>
<div class="col-md-12">
	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#view"><span class="glyphicon glyphicon-list"></span>&nbsp;&nbsp;View</a></li>
	  <li><a data-toggle="tab" href="#add"><span class="glyphicon glyphicon-plus"></span>&nbsp;&nbsp;Add</a></li>
	</ul>

	<div class="tab-content">
	  <div id="view" class="tab-pane fade in active">
	  	<br/>
    	<div class="col-md-12">
    		<div class="panel-group" id="accordion">
    			<?php
    				global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_timeblocks";
    				$cond_date = date("Y-m-d");
					$select_query = $wpdb->get_results($wpdb->prepare( "
						SELECT a.*,b.name as provider 
						FROM wp_wpab_timeblocks a
						INNER JOIN wp_wpab_providers b ON a.provider_id = b.id
						INNER JOIN wp_wpab_loc c ON a.id = c.avail_id
						INNER JOIN wp_wpab_serv d ON a.id = d.avail_id
						INNER JOIN wp_wpab_week e ON a.id = e.avail_id
						INNER JOIN wp_wpab_locations f ON c.location_id = f.id
						INNER JOIN wp_wpab_services g ON d.service_id = g.id
						GROUP BY a.valid_from,a.valid_to
					",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
					<div class="panel panel-default">
				      <div class="panel-heading">
				        <h4 class="panel-title">
				          <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $value->id ?>"><?php echo $value->provider ?></a>
				          <p class="pull-right">(<?php echo $value->valid_from ?> - <?php echo $value->valid_to ?>)&nbsp;&nbsp;&nbsp;&nbsp;<span class="glyphicon glyphicon-time gi-2x"></span>&nbsp;<u><?php echo gmdate("H:i", $value->starts_at) ?> - <?php echo gmdate("H:i", $value->ends_at) ?></u></p>
				        </h4>
				      </div>
				      <div id="collapse<?php echo $value->id ?>" class="panel-collapse collapse">
				        <div class="panel-body">
				        
				        </div>
				      </div>
				    </div>
				<?php
					endforeach;
					}
					else { 
				?>
					<h4>No Availability</h4>
				<?php
					}
    			?>			    
			</div>
    	</div>
	  </div>
	  <div id="add" class="tab-pane fade">
	    <br/><br/>
	    <form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="provider">Provider</label>
		    <div class="col-sm-10">
		      <select class="form-control" id="provider" name="provider" data-live-search="true" title="Select Provider" required="required">
		      	<?php
		      		global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_providers";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,name FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
						<option value="<?php echo $value->id ?>"><?php echo $value->name ?></option>
					
				<?php
					endforeach;
					}
					else { 
				?>
					<option>No Records To Display !</option>
				<?php
					}
		      	?>
			  </select>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Locations</label>
		    <div class="col-sm-10">
		    	<?php
		      		global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_locations";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,name FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
						<label class="checkbox-inline"><input type="checkbox" value="<?php echo $value->id ?>" name="loc[]"><?php echo $value->name ?></label>
					
				<?php
					endforeach;
					}
					else { 
				?>
					<span>No Records To Display !</span>
				<?php
					}
		      	?> 
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Services</label>
		    <div class="col-sm-10"> 
		      	<?php
		      		global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_services";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,name FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
						<label class="checkbox-inline"><input type="checkbox" value="<?php echo $value->id ?>" name="serv[]"><?php echo $value->name ?></label>
					
				<?php
					endforeach;
					}
					else { 
				?>
					<span>No Records To Display !</span>
				<?php
					}
		      	?>
		    </div>
		  </div>
		  <!-- <div class="form-group">
		    <label class="control-label col-sm-2" for="">Slot Type</label>
		    <div class="col-sm-10">
		      	<label class="radio-inline"><input type="radio" name="optradio">Option 1</label>
				<label class="radio-inline"><input type="radio" name="optradio">Option 2</label>
		    </div>
		  </div> -->
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Time</label>
		    <div class="col-sm-10">
		      <div class="col-md-3">
			      <select class="form-control" id="starttime" name="starttime" title="Start Time" required="required">
			      	<?php 
		      		$start = "00:00";
					$end = "24:00";

					$tStart = strtotime($start);
					$tEnd = strtotime($end);
					$tNow = $tStart;
					$tSecs = 0;

					while($tNow <= $tEnd){
					  echo "<option value='" . $tSecs*60 . "'>" . date("h:i A",$tNow) . "</option>";
					  $tNow = strtotime('+15 minutes',$tNow);
					  $tSecs += 15;
					}
		      		?>
				  </select>
			  </div>
			  <div class="col-md-3">
				  <select class="form-control" id="endtime" name="endtime" title="End Time" required="required">
				  	<?php 
		      		$start = "00:00";
					$end = "24:00";

					$tStart = strtotime($start);
					$tEnd = strtotime($end);
					$tNow = $tStart;
					$tSecs = 0;

					while($tNow <= $tEnd){
					  echo "<option value='" . $tSecs*60 . "'>" . date("h:i A",$tNow) . "</option>";
					  $tNow = strtotime('+15 minutes',$tNow);
					  $tSecs += 15;
					}
		      		?>
				  </select>
			  </div>
			  <div class="col-md-6">
			  	  <div class="col-md-2">Interval</div>
			  	  <div class="col-md-4">
					  <select class="form-control" id="interval" name="interval" required="required">
					  	<option value="300">5</option><option value="600">10</option><option value="900">15</option><option value="1200">20</option><option value="1500">25</option><option value="1800">30</option><option value="2400">40</option><option value="2700">45</option><option value="3000">50</option><option value="3600">60</option><option value="4500">75</option><option value="5400">90</option><option value="7200">120</option><option value="9000">150</option><option value="10800">180</option><option value="14400">240</option><option value="18000">300</option><option value="21600">360</option><option value="28800">480</option><option value="32400">540</option><option value="43200">720</option><option value="64800">1080</option><option value="86400">1440</option>
					  </select>
				  </div>
			  </div>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">When</label>
		    <div class="col-sm-10">
		      	<label class="radio-inline"><input type="radio" name="appt_when" value="0">Every Week</label>
				<label class="radio-inline"><input type="radio" name="appt_when" value="1">This Date Only</label>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Weekdays</label>
		    <div class="col-sm-10"> 
		      	<label class="checkbox-inline"><input type="checkbox" value="0" name="weekdays[]">Sun</label>
				<label class="checkbox-inline"><input type="checkbox" value="1" name="weekdays[]">Mon</label>
				<label class="checkbox-inline"><input type="checkbox" value="2" name="weekdays[]">Tue</label>
				<label class="checkbox-inline"><input type="checkbox" value="3" name="weekdays[]">Wed</label>
				<label class="checkbox-inline"><input type="checkbox" value="4" name="weekdays[]">Thu</label>
				<label class="checkbox-inline"><input type="checkbox" value="5" name="weekdays[]">Fri</label>
				<label class="checkbox-inline"><input type="checkbox" value="6" name="weekdays[]">Sat</label>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="">Dates</label>
		    <div class="col-sm-10"> 
		      	<div class='col-md-5'>
			        <div class="form-group">
			            <div class='input-group date' id='datetimepicker6'>
			                <input type='text' class="form-control" name="valid_from" required="required" />
			                <span class="input-group-addon">
			                    <span class="glyphicon glyphicon-calendar"></span>
			                </span>
			            </div>
			        </div>
			    </div>
			    <div class='col-md-5'>
			        <div class="form-group">
			            <div class='input-group date' id='datetimepicker7'>
			                <input type='text' class="form-control" name="valid_to" required="required" />
			                <span class="input-group-addon">
			                    <span class="glyphicon glyphicon-calendar"></span>
			                </span>
			            </div>
			        </div>
			    </div>
				<script type="text/javascript">
				    $(function () {
				        $('#datetimepicker6').datetimepicker({
				        	format: 'YYYY-MM-DD'
				        });
				        $('#datetimepicker7').datetimepicker({
				        	format: 'YYYY-MM-DD',
				            useCurrent: false //Important! See issue #1075
				        });
				        $("#datetimepicker6").on("dp.change", function (e) {
				            $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
				        });
				        $("#datetimepicker7").on("dp.change", function (e) {
				            $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
				        });
				    });
				</script>
		    </div>
		  </div>
		  <!-- <div class="form-group">
		    <label class="control-label col-sm-2" for="">Min Adv. Booking</label>
		    <div class="col-sm-10"> 
		      	<ul class="list-inline list-separated">
		      		<li>
		      			<input class="form-control" type="text" id="" name="" value="3" size="2" style="">
		      		</li>
		      		<li>
		      			<select id="" name="" style="width: auto;" class="form-control">
		      				<option value="m">Minutes</option>
		      				<option value="h" selected>Hours</option>
		      				<option value="d">Days</option>
		      				<option value="w">Weeks</option>
		      			</select>
		      		</li>
		      	</ul>
		    </div>
		  </div> -->
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="capacity">Capacity</label>
		    <div class="col-sm-10"> 
		      	<input type="text" name="capacity" class="form-control" id="capacity" pattern="[0-9]+" value="1" required="required">
		    </div>
		  </div>
		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default" name="form-submitted">Add Availability</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#provider').selectpicker({
		  size: 8
		});
		$('#starttime,#endtime').selectpicker();
	});	
</script>

<script type="text/javascript">
	$(document).ready(function() {
		$(".alert-dismissable").fadeTo(2000, 500).slideUp(500, function(){
		    $(".alert-dismissable").alert('close');
		});
	});		
</script>