<?php
	if(!empty($_GET['msg']) && $_GET['msg']==2) {
    	$message = $_GET['msg'];
?>
<div class="alert alert-success msg">
  <strong>Deleted!</strong> Customer deleted successfully !
</div>
<?php
    }
?>

<?php
	if(!empty($_GET['msg']) && $_GET['msg']==1) {
    	$message = $_GET['msg'];
?>
<div class="alert alert-success msg">
  <strong>Updated!</strong> Customer edited successfully !
</div>
<?php
    }
?>

<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_customers";

        // sanitize form values
        $firstname   = sanitize_text_field( $_POST["firstname"] );
        $lastname    = sanitize_text_field( $_POST["lastname"] );
        $username    = sanitize_text_field( $_POST["username"] );
        $password    = sanitize_text_field( $_POST["password"] );
        $email = sanitize_email( $_POST["email"] );

       	$query =  $wpdb->query($wpdb->prepare(
		    "INSERT INTO $table_name (first_name, last_name, username, email, password) VALUES ( %s, %s, %s, %s, %s )",
		    array(
		        $firstname,
		        $lastname,
		        $username,
		        $email,
		        $password
		    )
		));

        if($query){
	        $msg_success = "<div class='alert alert-info alert-dismissable'>Customer has been successfully created</div>";
        }
        else{
        	$msg_success = "<div class='alert alert-warning alert-dismissable'>Customer has not been created</div>";
        }
    }
?>


<div class="page-header">
<?php
	$var = $GLOBALS['title'];
	echo "<h1 class=''>$var</h1>";
?>
<?php echo $msg_success; ?>
</div>
<div class="col-md-12">
	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#view"><span class="glyphicon glyphicon-list"></span>&nbsp;&nbsp;View</a></li>
	  <li><a data-toggle="tab" href="#add"><span class="glyphicon glyphicon-plus"></span>&nbsp;&nbsp;Add</a></li>
	</ul>

	<div class="tab-content">
		<div id="view" class="tab-pane fade in active">
			<br/>
			<div class="col-md-12">
				<?php 
					global $wpdb;
    				$table_name = $wpdb->prefix . "wpab_customers";
					$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,first_name,last_name,email FROM $table_name",""));
					if($select_query){
						foreach ($select_query as $value):
				?>
					<div class="col-md-3 col-sm-6">
						<div class="alert alert-regular alert-success">
							<ul class="list-unstyled">
								<li class="text-muted text-smaller pull-right">
									<a href="<?php echo admin_url() ?>?page=wpab_customer_edit&id=<?php echo $value->id ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>" class="edit" data-id="<?php echo $value->id ?>"><span class="glyphicon glyphicon-edit"></span></a>
							    	&nbsp;
							    	<a href="<?php echo plugin_dir_url( __FILE__ ) ?>delete/delete-customer.php?id=<?php echo $value->id ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>" class="delete" data-id="<?php echo $value->id ?>"><span class="glyphicon glyphicon-trash"></span></a>
								</li>
								<li class="squeeze-in">
									<a class="" href="">
										<strong><?php echo $value->first_name . " " . $value->last_name ?></strong>
									</a>
								</li>
								<li class="squeeze-in"><?php echo $value->email ?></li>
							</ul>
						</div>
					</div>
				<?php
					endforeach;
					}
					else { 
				?>
					<h5 align="center">No Records To Display !</h5>					
				<?php
					}
				?>
			</div>
		</div>
	  <div id="add" class="tab-pane fade">
	    <br/><br/>
	    <form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="firstname">First Name</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="firstname" pattern="[a-zA-Z0-9 ]+" name="firstname" required="required">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="lastname">Last Name</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="lastname" pattern="[a-zA-Z0-9 ]+" name="lastname" required="required">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="username">Username</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="username" pattern="[a-zA-Z0-9 ]+" name="username" required="required">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="email">Email</label>
		    <div class="col-sm-10">
		      <input type="email" class="form-control" id="email" name="email" required="required">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="password">Password</label>
		    <div class="col-sm-10">
		    	<div class="input-group">
			    	<input type="password" class="form-control pwd-view" id="password" pattern="[a-zA-Z0-9 ]+" name="password" required="required">
			    	<span class="input-group-addon cur-point"><span class="glyphicon glyphicon-eye-close pwd-view-toggle"></span></span>
		    	</div>
		    </div>
		  </div>
		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default" name="form-submitted">Add New Customer</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('.pwd-view-toggle').click(function(event) {
			/* Act on the event */
			$type = $('.pwd-view').attr('type');
			//console.log($type);

			if($type == 'password')
				$('.pwd-view').attr('type', 'text');
			if($type == 'text')
				$('.pwd-view').attr('type', 'password');
		});
	});
</script>

<script type="text/javascript">
	$(document).ready(function() {
		$(".alert-dismissable,.msg").fadeTo(2000, 500).slideUp(500, function(){
		    $(".alert-dismissable,.msg").alert('close');
		});
	});		
</script>