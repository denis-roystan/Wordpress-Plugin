<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	$data = $_POST['customer_name'];
	//echo $data;
	
	global $wpdb;
	$table_name = $wpdb->prefix . "wpab_customers";
	$select_query = $wpdb->get_results($wpdb->prepare( "SELECT id,first_name,last_name,email FROM $table_name WHERE id=$data",""));
	if($select_query){
		foreach ($select_query as $value){
		$result = $value->email;
		}
	}
	else { 
		$result  = "NO EMAIL ID";
	}

	echo $result;
?>