<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	$disabled = array();

	$data1 = $_POST['starts_at'];
	$data2 = $_POST['ends_at'];
	$data3 = $_POST['interval'];

	$data4 = $_POST['location_name'];
	$data5 = $_POST['service_name'];
	$data6 = $_POST['provider_name'];

	global $wpdb;
	$table_name1 = $wpdb->prefix . "wpab_appointments";

	$select_query = $wpdb->get_results($wpdb->prepare( "SELECT * FROM $table_name1 WHERE location_id = $data4 AND service_id = $data5 AND provider_id = $data6",""));
	if($select_query){
		foreach ($select_query as $value){
			$oDate = new DateTime($value->starts_at);
			$sDate = $oDate->format("H:i");
			array_push($disabled, $sDate);
		}
	}
	else { 
		$disabled  = array();
	}

	
	function time_disp($start_at,$end_at,$interval){
		$start = $start_at;
		$end = $end_at;
		global $disabled;
		$tStart = strtotime($start);
		$tEnd = strtotime($end);
		$tNow = $tStart;
		$tans = "";

		while($tNow <= $tEnd){
		  $temp = date("H:i",$tNow);
		  if (in_array($temp, $disabled))
		  {
		  	$tans = $tans . "<button type='button' value='' disabled='disabled' class='btn btn-danger btn-sm col-xs-2 disabled' style='margin:1px;''>" . date("H:i",$tNow) . "</button>";
		  }
		  else
		  {
		  	$tans = $tans . "<button type='button' value='' class='btn btn-default btn-sm col-xs-2' style='margin:1px;''>" . date("H:i",$tNow) . "</button>";
		  }
		  
		  $tNow = strtotime('+' . $interval . ' minutes',$tNow);
		}

		return $tans;
	}

	$result = time_disp($data1, $data2, $data3);

	echo $result;
?>