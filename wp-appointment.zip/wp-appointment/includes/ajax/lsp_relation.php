<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	$data1 = $_POST['location_name'];
	$data2 = $_POST['service_name'];
	//echo $data;
	
	global $wpdb;
	$table_name1 = $wpdb->prefix . "wpab_timeblocks";
	$table_name2 = $wpdb->prefix . "wpab_loc";
	$table_name3 = $wpdb->prefix . "wpab_serv";
	$table_name4 = $wpdb->prefix . "wpab_providers";

	$select_query = $wpdb->get_results($wpdb->prepare( "
		SELECT d.id,d.name 
		FROM wp_wpab_timeblocks a
		INNER JOIN wp_wpab_loc b ON a.id = b.avail_id
		INNER JOIN wp_wpab_serv c ON a.id = c.avail_id
		INNER JOIN wp_wpab_providers d ON a.provider_id = d.id
		WHERE b.location_id = $data1
		AND c.service_id = $data2
		GROUP BY d.id
	",""));
	if($select_query){
		$result = "";
		foreach ($select_query as $value){
			$result = $result . "<option value='" . $value->id . "'>" . $value->name . "</option>";
		}
	}
	else { 
		$result  = "<option>No Services/option>";
	}

	echo $result;
?>