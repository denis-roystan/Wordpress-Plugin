<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	$data = $_POST['location_name'];
	//echo $data;
	
	global $wpdb;
	$table_name1 = $wpdb->prefix . "wpab_timeblocks";
	$table_name2 = $wpdb->prefix . "wpab_loc";
	$table_name3 = $wpdb->prefix . "wpab_serv";
	$table_name4 = $wpdb->prefix . "wpab_services";

	$select_query = $wpdb->get_results($wpdb->prepare( "
		SELECT d.id, d.name, d.price, d.duration 
		FROM $table_name1 a
		INNER JOIN $table_name2 b ON a.id = b.avail_id
		INNER JOIN $table_name3 c ON a.id = c.avail_id
		INNER JOIN $table_name4 d ON c.service_id = d.id
		WHERE b.location_id = $data
		GROUP BY c.service_id
	",""));
	if($select_query){
		$result = "";
		foreach ($select_query as $value){
			$result = $result . "<option value='" . $value->id . "' data-price='" . $value->price . "' data-duration='" . $value->duration . "'>" . $value->name . "</option>";
		}
	}
	else { 
		$result  = "<option>No Services/option>";
	}

	echo $result;
?>