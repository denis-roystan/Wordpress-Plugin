<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	function secToHR($seconds) {
	  $hours = floor($seconds / 3600);
	  $minutes = floor(($seconds / 60) % 60);
	  $num_padded = sprintf("%02d", $minutes);
	  // $seconds = $seconds % 60;
	  return "$hours:$num_padded";
	}

	function secToMIN($seconds){
		$minutes = floor(($seconds / 60));
		return $minutes;
	}

	/*function time_disp($start_at,$end_at,$interval){
		$start = $start_at;
		$end = $end_at;

		$tStart = strtotime($start);
		$tEnd = strtotime($end);
		$tNow = $tStart;
		$tans = "";

		while($tNow <= $tEnd){
		  $tans = $tans . "<button type='button' class='btn btn-default btn-sm col-xs-2' style='margin:1px;''>" . date("H:i",$tNow) . "</button>";
		  //$tNow = strtotime('+' + $interval + 'minutes',$tNow);
		}

		return $tans;
	}*/

	$data1 = $_POST['location_name'];
	$data2 = $_POST['service_name'];
	$data3 = $_POST['provider_name'];
	//echo $data;
	
	global $wpdb;
	$table_name1 = $wpdb->prefix . "wpab_timeblocks";
	$table_name2 = $wpdb->prefix . "wpab_loc";
	$table_name3 = $wpdb->prefix . "wpab_serv";
	$table_name4 = $wpdb->prefix . "wpab_providers";

	$select_query = $wpdb->get_results($wpdb->prepare( "
		SELECT a . *, d.id, d.name
		FROM $table_name1 a
		INNER JOIN $table_name2 b ON a.id = b.avail_id
		INNER JOIN $table_name3 c ON a.id = c.avail_id
		INNER JOIN $table_name4 d ON a.provider_id = d.id
		WHERE b.location_id = $data1
		AND c.service_id = $data2
		AND d.id = $data3
		GROUP BY b.location_id,c.service_id,d.id
	",""));
	if($select_query){
		$result = "";
		foreach ($select_query as $value){
			$ans1 = $value->valid_from;
			$ans2 = $value->valid_to;
			$ans3 = secToHR($value->starts_at);
			$ans4 = secToHR($value->ends_at);
			$ans5 = secToMIN($value->appt_interval);
			//$avl_time = time_disp($ans3,$ans4,$ans5);
			$result = array($ans1 , $ans2 , $ans3 , $ans4 , $ans5);
		}
	}
	else { 
		$result  = "";
	}

	echo json_encode($result);
?>