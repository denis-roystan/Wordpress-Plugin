<?php
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );

	$id = $_GET['id'];
	$redirect = $_GET['redirect_url'];

	global $wpdb;
	$table_name1 = $wpdb->prefix . "wpab_providers";

	$delete_query = $wpdb->query($wpdb->prepare( "DELETE FROM $table_name1 WHERE id=%s",array( $id )));

	if($delete_query){
		header("Location: " . urldecode($redirect) . "&msg=2");
		die();
	}
	else {

	}
?>