<?php
	$edit_id = $_GET['id'];
	$redirect_url = $_GET['redirect_url'];
?>

<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_customers";

        // sanitize form values
       	$firstname   = sanitize_text_field( $_POST["firstname"] );
        $lastname    = sanitize_text_field( $_POST["lastname"] );
        $username    = sanitize_text_field( $_POST["username"] );
        //$password    = sanitize_text_field( $_POST["password"] );
        $email = sanitize_email( $_POST["email"] );
        $id = absint( $_POST["id"] );

       	$query =  $wpdb->query($wpdb->prepare(
		    "UPDATE $table_name SET first_name=%s, last_name=%s, username=%s, email=%s WHERE id=%s",
		    array(
		    	$firstname,
		        $lastname,
		        $username,
		        $email,
		        $id
		    )
		));

        if($query){
	    	header("Location: " . urldecode($redirect_url) . "&msg=1");
			die();
        }
        else{
        	
        }
    }
?>

<div class="page-header">
	<h1 class=''>Edit Customer</h1>
</div>

<div class="col-md-10">
	<?php 
		global $wpdb;
		$table_name = $wpdb->prefix . "wpab_customers";
		$select_query = $wpdb->get_row($wpdb->prepare( "SELECT id,first_name,last_name,username,email FROM $table_name WHERE id=%s",array( $edit_id )));
		if($select_query){
			$firstname = $select_query->first_name;
			$lastname = $select_query->last_name;
			$username = $select_query->username;
			$email = $select_query->email;
		}
		else {
			
		}
	?>
	<br/><br/>
	<form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
	  <input type="hidden" name="id" value="<?php echo $edit_id ?>">
	  <div class="form-group">
		    <label class="control-label col-sm-2" for="firstname">First Name</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="firstname" pattern="[a-zA-Z0-9 ]+" name="firstname" required="required" value="<?php echo $firstname ?>">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="lastname">Last Name</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="lastname" pattern="[a-zA-Z0-9 ]+" name="lastname" required="required" value="<?php echo $lastname ?>">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="username">Username</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="username" pattern="[a-zA-Z0-9 ]+" name="username" required="required" value="<?php echo $username ?>">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="email">Email</label>
		    <div class="col-sm-10">
		      <input type="email" class="form-control" id="email" name="email" required="required" value="<?php echo $email ?>">
		    </div>
		  </div>
		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default" name="form-submitted">Edit Customer</button>
		    </div>
		  </div>
	</form>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('.pwd-view-toggle').click(function(event) {
			/* Act on the event */
			$type = $('.pwd-view').attr('type');
			//console.log($type);

			if($type == 'password')
				$('.pwd-view').attr('type', 'text');
			if($type == 'text')
				$('.pwd-view').attr('type', 'password');
		});
	});
</script>