<?php
	$edit_id = $_GET['id'];
	$redirect_url = $_GET['redirect_url'];
?>

<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_locations";

        // sanitize form values
        $name    = sanitize_text_field( $_POST["title"] );
        $description = esc_textarea( $_POST["description"] );
        $capacity = absint( $_POST["capacity"] );
        $id = absint( $_POST["id"] );

       	$query =  $wpdb->query($wpdb->prepare(
		    "UPDATE $table_name SET name=%s, description=%s, capacity=%s WHERE id=%s",
		    array(
		        $name,
		        $description,
		        $capacity,
		        $id
		    )
		));

        if($query){
	       	header("Location: " . urldecode($redirect_url) . "&msg=1");
			die();
        }
        else{
        	
        }
    }
?>

<div class="page-header">
	<h1 class=''>Edit Location</h1>
</div>

<div class="col-md-10">
	<?php 
		global $wpdb;
		$table_name = $wpdb->prefix . "wpab_locations";
		$select_query = $wpdb->get_row($wpdb->prepare( "SELECT id,name,description,capacity FROM $table_name WHERE id=%s",array( $edit_id )));
		if($select_query){
			$title = $select_query->name;
			$description = $select_query->description;
			$capacity = $select_query->capacity;
		}
		else {
			
		}
	?>
	<br/><br/>
	<form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
	  <input type="hidden" name="id" value="<?php echo $edit_id ?>">
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="title">Title</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" pattern="[a-zA-Z0-9 ]+" id="title" name="title" required="required" value="<?php echo $title ?>">
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="description">Description</label>
	    <div class="col-sm-10"> 
	      <textarea class="form-control" rows="5" id="description" name="description" required="required"><?php echo $description ?></textarea>
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="capacity">Capacity</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="capacity" name="capacity" pattern="[0-9]+" value="<?php echo $capacity ?>">
	      <span class="help-block">Enter 0 for no limit</span>
	    </div>
	  </div>
	  <div class="form-group"> 
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default" name="form-submitted">Edit Location</button>
	    </div>
	  </div>
	</form>
</div>
