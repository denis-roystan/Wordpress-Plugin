<?php
	$edit_id = $_GET['id'];
	$redirect_url = $_GET['redirect_url'];
?>

<?php
    if ( isset( $_POST['form-submitted'] ) ) {

    	global $wpdb;
    	$table_name = $wpdb->prefix . "wpab_providers";

        // sanitize form values
       	$name    = sanitize_text_field( $_POST["title"] );
        $description = esc_textarea( $_POST["description"] );
        $email = sanitize_email( $_POST["email"] );
        $id = absint( $_POST["id"] );

       	$query =  $wpdb->query($wpdb->prepare(
		    "UPDATE $table_name SET name=%s, description=%s, email=%s WHERE id=%s",
		    array(
		    	$name,
		        $description,
		        $email,
		        $id
		    )
		));

        if($query){
	    	header("Location: " . urldecode($redirect_url) . "&msg=1");
			die();
        }
        else{
        	
        }
    }
?>

<div class="page-header">
	<h1 class=''>Edit Provider</h1>
</div>

<div class="col-md-10">
	<?php 
		global $wpdb;
		$table_name = $wpdb->prefix . "wpab_providers";
		$select_query = $wpdb->get_row($wpdb->prepare( "SELECT id,name,description,email FROM $table_name WHERE id=%s",array( $edit_id )));
		if($select_query){
			$title = $select_query->name;
			$description = $select_query->description;
			$email = $select_query->email;
		}
		else {
			
		}
	?>
	<br/><br/>
	<form class="form-horizontal col-md-8 col-md-offset-1" method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data">
	  <input type="hidden" name="id" value="<?php echo $edit_id ?>">
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="title">Name</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" pattern="[a-zA-Z0-9 ]+" id="title" name="title" required="required" value="<?php echo $title ?>">
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="description">Description</label>
	    <div class="col-sm-10"> 
	      <textarea class="form-control" rows="5" id="description" name="description" required="required"><?php echo $description ?></textarea>
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="email">Email</label>
	    <div class="col-sm-10">
	      <input type="email" class="form-control" id="email" name="email" required="required" value="<?php echo $email ?>">
	    </div>
	  </div>
	  <div class="form-group"> 
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default" name="form-submitted">Edit Provider</button>
	    </div>
	  </div>
	</form>
</div>