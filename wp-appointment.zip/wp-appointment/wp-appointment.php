<?php
/*
Plugin Name: Appointment Booking
Description: An Appointment Booking Plugin
Version: 1.0
Author: Denis Roystan Dalmeida
*/
?>
<?php
register_activation_hook( __FILE__, 'wpab_install' );
register_activation_hook( __FILE__, 'wpab_create_db' );

function wpab_install()
{
	global $wp_version;

	$php = '5.3';
	$wp  = '3.5';

	if ( version_compare( PHP_VERSION, $php, '<' ) ) {
		deactivate_plugins( basename( __FILE__ ) );
		wp_die(
			'<p>' .
			sprintf(
				__( 'This plugin can not be activated because it requires a PHP version greater than %1$s. Your PHP version can be updated by your hosting company.', 'my_plugin' ),
				$php
			)
			. '</p> <a href="' . admin_url( 'plugins.php' ) . '">' . __( '<- Go Back', 'my_plugin' ) . '</a>'
		);
	}

	if ( version_compare( $wp_version, $wp, '<' ) ) {
		deactivate_plugins( basename( __FILE__ ) );
		wp_die(
			'<p>' .
			sprintf(
				__( 'This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to run the latest version of WordPress .', 'my_plugin' ),
				$wp
			)
			. '</p> <a href="' . admin_url( 'plugins.php' ) . '">' . __( '<- Go Back', 'my_plugin' ) . '</a>'
		);
	}
}

function wpab_create_db()
{
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$appointment_table_name = $wpdb->prefix . 'wpab_appointments';
	$conf_table_name = $wpdb->prefix . 'wpab_conf';
	$service_table_name = $wpdb->prefix . 'wpab_services';
	$timeoff_table_name = $wpdb->prefix . 'wpab_timeoff';
	$location_table_name = $wpdb->prefix . 'wpab_locations';
	$provider_table_name = $wpdb->prefix . 'wpab_providers';
	$customer_table_name = $wpdb->prefix . 'wpab_customers';
	$timeblock_table_name = $wpdb->prefix . 'wpab_timeblocks';
	$week_table_name = $wpdb->prefix . 'wpab_week';
	$loc_table_name = $wpdb->prefix . 'wpab_loc';
	$serv_table_name = $wpdb->prefix . 'wpab_serv';

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	$sql = "CREATE TABLE $appointment_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		customer_id int(11) NOT NULL,
		service_id int(11) NOT NULL,
		provider_id int(11) NOT NULL,
		location_id int(11) NOT NULL,
		seats int(11) NOT NULL DEFAULT 1,
		starts_at datetime NOT NULL,
		duration int(11) NOT NULL,
		price int(11) NOT NULL,
		approved tinyint(4) NOT NULL DEFAULT 1,
		completed tinyint(4) NOT NULL DEFAULT 0,
		created_at timestamp default now(),
		priority int(11) NOT NULL DEFAULT 1,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql );

	$sql2 = "CREATE TABLE $conf_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		value text NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql2 );

	$sql3 = "CREATE TABLE $service_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		description text NOT NULL,
		duration int(11) NOT NULL,
		price varchar(255) NOT NULL,
		priority int(11) NOT NULL DEFAULT 1,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql3 );

	/*$sql4 = "CREATE TABLE $timeoff_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		value text NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql4 );*/

	$sql5 = "CREATE TABLE $location_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		description text NOT NULL,
		capacity int(11) NOT NULL,
		priority int(11) NOT NULL DEFAULT 1,
		archive int(11) NOT NULL DEFAULT 0,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql5 );

	$sql6 = "CREATE TABLE $provider_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		email varchar(255) NOT NULL,
		name varchar(255) NOT NULL,
		description text NOT NULL,
		priority int(11) NOT NULL DEFAULT 1,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql6 );

	$sql7 = "CREATE TABLE $customer_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		email varchar(255) NOT NULL UNIQUE,
		username varchar(255) NOT NULL,
		first_name varchar(255) NOT NULL,
		last_name varchar(255) NOT NULL,
		password varchar(255) NOT NULL,
		created timestamp default now(),
		lang varchar(255) NOT NULL DEFAULT 'en',
		priority int(11) NOT NULL DEFAULT 1,
		UNIQUE KEY id (id)
	) $charset_collate AUTO_INCREMENT=2;";

	dbDelta( $sql7 );

	$sql8 = "CREATE TABLE $timeblock_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		provider_id int(11) NOT NULL,
		slot_type int(11) NOT NULL DEFAULT 0,
		starts_at int(11) NOT NULL,
		ends_at int(11) NOT NULL,
		appt_interval int(11) NOT NULL,
		avl_when int(11) NOT NULL DEFAULT 0,
		valid_from varchar(255) NOT NULL,
		valid_to varchar(255) NOT NULL,
		min_adv_bk int(11) NOT NULL DEFAULT 1440,
		max_adv_bk int(11) NOT NULL DEFAULT 10080,
		capacity int(11) NOT NULL,
		max_capacity int(11) NOT NULL DEFAULT 1,
		created timestamp default now(),
		priority int(11) NOT NULL DEFAULT 1,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql8 );

	$sql9 = "CREATE TABLE $week_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		avail_id int(11) NOT NULL,
		week_id int(11) NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql9 );

	$sql10 = "CREATE TABLE $loc_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		avail_id int(11) NOT NULL,
		location_id int(11) NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql10 );

	$sql11 = "CREATE TABLE $serv_table_name (
		id int(11) NOT NULL AUTO_INCREMENT,
		avail_id int(11) NOT NULL,
		service_id int(11) NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";

	dbDelta( $sql11 );
}

register_deactivation_hook( __FILE__, 'wpab_deactivate' );

function wpab_deactivate()
{
	// do something
}

add_action( 'admin_menu', 'wpab_create_menu');

function wpab_create_menu()
{
	add_menu_page( 'Appointment Booking', 'Appointment', 'manage_options', 'wp_appointment_main_menu', 'appointment_main_page', plugins_url( '/images/ical.png', __FILE__ ));

	add_submenu_page( 'wp_appointment_main_menu', 'Availability', 'Availability', 'manage_options', 'wp_appointment_availability', 'appointment_availability_page' );
	//add_submenu_page( 'wp_appointment_main_menu', 'Time Off', 'Time Off', 'manage_options', 'wp_appointment_timeoff', 'appointment_timeoff_page' );
	add_submenu_page( 'wp_appointment_main_menu', 'Customers', 'Customers', 'manage_options', 'wp_appointment_customers', 'appointment_customers_page' );
	add_submenu_page( 'wp_appointment_main_menu', 'Services', 'Services', 'manage_options', 'wp_appointment_services', 'appointment_services_page' );
	add_submenu_page( 'wp_appointment_main_menu', 'Providers', 'Providers', 'manage_options', 'wp_appointment_providers', 'appointment_providers_page' );
	add_submenu_page( 'wp_appointment_main_menu', 'Locations', 'Locations', 'manage_options', 'wp_appointment_locations', 'appointment_locations_page' );
	add_submenu_page( 'wp_appointment_main_menu', 'Settings', 'Settings', 'manage_options', 'wp_appointment_settings', 'appointment_settings_page' );
	add_submenu_page( null, 'Location Edit', 'Location Edit', 'manage_options', 'wpab_location_edit', 'location_edit_page' );
	add_submenu_page( null, 'Service Edit', 'Service Edit', 'manage_options', 'wpab_service_edit', 'service_edit_page' );
	add_submenu_page( null, 'Provider Edit', 'Provider Edit', 'manage_options', 'wpab_provider_edit', 'provider_edit_page' );
	add_submenu_page( null, 'Customer Edit', 'Customer Edit', 'manage_options', 'wpab_customer_edit', 'customer_edit_page' );

}

function appointment_main_page()
{
	require_once 'includes/booking.php';

	/*$start = "9:00";
	$end = "20:00";

	$tStart = strtotime($start);
	$tEnd = strtotime($end);
	$tNow = $tStart;

	while($tNow <= $tEnd){
	  echo date("H:i",$tNow)."\n";
	  $tNow = strtotime('+30 minutes',$tNow);
	}*/
}

// Sub-Menu Pages

function appointment_availability_page()
{
	require_once 'includes/availability.php';
}

function appointment_timeoff_page()
{
	require_once 'includes/time_off.php';
}

function appointment_customers_page()
{
	require_once 'includes/customers.php';
}

function appointment_services_page()
{
	require_once 'includes/services.php';
}

function appointment_providers_page()
{
	require_once 'includes/providers.php';
}

function appointment_locations_page()
{
	require_once 'includes/locations.php';
}

function appointment_settings_page()
{
	require_once 'includes/settings.php';
}

// Edit Pages

function location_edit_page()
{
	require_once 'includes/edit/edit-location.php';
}

function service_edit_page()
{
	require_once 'includes/edit/edit-service.php';
}

function provider_edit_page()
{
	require_once 'includes/edit/edit-provider.php';
}

function customer_edit_page()
{
	require_once 'includes/edit/edit-customer.php';
}


// Frontend Form

function appointment_form_create(){
	require_once 'includes/appointment_form_front.php';
}

add_shortcode( 'WPAB_APPOINTMENT_BOOKING', 'appointment_form_create' );


// Scripts & Styles Load

function load_custom_wp_admin_style($hook) {
    // Load only on ?page=mypluginname
	/* if($hook != 'wp_appointment_main_menu') {
	        return;
	}*/
    wp_enqueue_style( 'custom_wpab_bt_css', plugins_url('css/bootstrap.min.css', __FILE__) );
    wp_enqueue_style( 'custom_wpab_btdt_css', plugins_url('css/bootstrap-datetimepicker.min.css', __FILE__) );
    wp_enqueue_style( 'custom_wpab_btst_css', plugins_url('css/bootstrap-select.min.css', __FILE__) );
    wp_enqueue_style( 'custom_wpab_style_css', plugins_url('css/wpab_style.css', __FILE__) );
    wp_enqueue_script( 'custom_wpab_jq_js', plugins_url('js/jquery.js', __FILE__) );
    wp_enqueue_script( 'custom_wpab_bt_js', plugins_url('js/bootstrap.min.js', __FILE__) );
    wp_enqueue_script( 'custom_wpab_ml_js', plugins_url('js/moment-with-locales.js', __FILE__) );
    wp_enqueue_script( 'custom_wpab_btdt_js', plugins_url('js/bootstrap-datetimepicker.min.js', __FILE__) );
    wp_enqueue_script( 'custom_wpab_btst_js', plugins_url('js/bootstrap-select.min.js', __FILE__) );
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );
add_action( 'wp_enqueue_scripts', 'load_custom_wp_admin_style' );
?>